/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: eml_rand_shr3cong_vrLt4K7H.h
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#ifndef eml_rand_shr3cong_vrLt4K7H_h_
#define eml_rand_shr3cong_vrLt4K7H_h_
#include "rtwtypes.h"

extern real_T eml_rand_shr3cong_vrLt4K7H(uint32_T state[2]);

#endif                                 /* eml_rand_shr3cong_vrLt4K7H_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
