/*
 * const_params.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "carsim_ekf_onlyfunction".
 *
 * Model version              : 2.12
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C source code generated on : Thu Apr 25 20:21:24 2024
 */
#include "rtwtypes.h"

extern const real_T rtCP_pooled_BrF7RapXGBLM[9];
const real_T rtCP_pooled_BrF7RapXGBLM[9] = { 0.01, 0.0, 0.0, 0.0, 0.01, 0.0, 0.0,
  0.0, 1.0 } ;

extern const real_T rtCP_pooled_MHWz5kUtmbx4[9];
const real_T rtCP_pooled_MHWz5kUtmbx4[9] = { 0.2449489742783178, 0.0, 0.0, 0.0,
  0.83666002653407556, 0.0, 0.0, 0.0, 0.022360679774997897 } ;

extern const real_T rtCP_pooled_Q4cddNHAmHWP[9];
const real_T rtCP_pooled_Q4cddNHAmHWP[9] = { 0.0031622776601683794, 0.0, 0.0,
  0.0, 0.0031622776601683794, 0.0, 0.0, 0.0, 0.0031622776601683794 } ;
