/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: genrand_uint32_vector_qilyMafa.c
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#include "rtwtypes.h"
#include "genrand_uint32_vector_qilyMafa.h"

/* Function for MATLAB Function: '<S5>/MATLAB Function' */
void genrand_uint32_vector_qilyMafa(uint32_T mt[625], uint32_T u[2])
{
  int32_T j;
  int32_T kk;
  for (j = 0; j < 2; j++) {
    uint32_T mti;
    uint32_T y;
    mti = mt[624] + 1U;
    if (mt[624] + 1U >= 625U) {
      for (kk = 0; kk < 227; kk++) {
        mti = (mt[kk + 1] & 2147483647U) | (mt[kk] & 2147483648U);
        if ((mti & 1U) == 0U) {
          mti >>= 1U;
        } else {
          mti = mti >> 1U ^ 2567483615U;
        }

        mt[kk] = mt[kk + 397] ^ mti;
      }

      for (kk = 0; kk < 396; kk++) {
        mti = (mt[kk + 227] & 2147483648U) | (mt[kk + 228] & 2147483647U);
        if ((mti & 1U) == 0U) {
          mti >>= 1U;
        } else {
          mti = mti >> 1U ^ 2567483615U;
        }

        mt[kk + 227] = mt[kk] ^ mti;
      }

      mti = (mt[623] & 2147483648U) | (mt[0] & 2147483647U);
      if ((mti & 1U) == 0U) {
        mti >>= 1U;
      } else {
        mti = mti >> 1U ^ 2567483615U;
      }

      mt[623] = mt[396] ^ mti;
      mti = 1U;
    }

    y = mt[(int32_T)mti - 1];
    mt[624] = mti;
    y ^= y >> 11U;
    y ^= y << 7U & 2636928640U;
    y ^= y << 15U & 4022730752U;
    u[j] = y >> 18U ^ y;
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
