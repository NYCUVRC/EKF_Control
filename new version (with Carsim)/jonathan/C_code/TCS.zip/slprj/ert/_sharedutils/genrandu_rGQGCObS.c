/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: genrandu_rGQGCObS.c
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#include "rtwtypes.h"
#include "genrandu_rGQGCObS.h"

/* Function for MATLAB Function: '<S5>/MATLAB Function' */
void genrandu_rGQGCObS(uint32_T s, uint32_T *state, real_T *r)
{
  int32_T hi;
  uint32_T a;
  uint32_T b;
  hi = (int32_T)(s / 127773U);
  a = (s - (uint32_T)hi * 127773U) * 16807U;
  b = 2836U * (uint32_T)hi;
  if (a < b) {
    *state = ~(b - a) & 2147483647U;
  } else {
    *state = a - b;
  }

  *r = (real_T)*state * 4.6566128752457969E-10;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
