/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: rt_hypotd_snf.h
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#ifndef rt_hypotd_snf_h_
#define rt_hypotd_snf_h_
#include "rtwtypes.h"

extern real_T rt_hypotd_snf(real_T u0, real_T u1);

#endif                                 /* rt_hypotd_snf_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
