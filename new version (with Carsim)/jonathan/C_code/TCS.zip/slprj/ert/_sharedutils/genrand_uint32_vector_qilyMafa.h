/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: genrand_uint32_vector_qilyMafa.h
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#ifndef genrand_uint32_vector_qilyMafa_h_
#define genrand_uint32_vector_qilyMafa_h_
#include "rtwtypes.h"

extern void genrand_uint32_vector_qilyMafa(uint32_T mt[625], uint32_T u[2]);

#endif                                 /* genrand_uint32_vector_qilyMafa_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
