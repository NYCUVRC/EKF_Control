/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: div_nde_s32_floor.h
 *
 * Code generated for Simulink model 'carsim_ekf_onlyfunction'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Thu Apr 25 20:21:24 2024
 */

#ifndef div_nde_s32_floor_h_
#define div_nde_s32_floor_h_
#include "rtwtypes.h"

extern int32_T div_nde_s32_floor(int32_T numerator, int32_T denominator);

#endif                                 /* div_nde_s32_floor_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
